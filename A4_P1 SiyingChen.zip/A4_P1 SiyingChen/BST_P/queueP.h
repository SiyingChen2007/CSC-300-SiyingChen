#ifndef QUEUEP_H
#define QUEUEP_H

#include "bstP.h"
#include <stdexcept>

// Linked-list queue from Assignment 1, changed to store BST node pointers.
struct queueNode
{
    node* data;
    queueNode* next;
    queueNode(node* value);
};

class Queue
{
    private:
        queueNode* front;
        queueNode* rear;
    public:
        Queue();
        ~Queue();
        void enqueue(node* value);
        node* dequeue();
        bool isEmpty();
};

#endif
