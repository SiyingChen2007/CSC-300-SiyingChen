#include "bstP.h"
#include "queueP.h"

node::node(int value)
{
    data = value;
    leftChild = nullptr;
    rightChild = nullptr;
}

BST::BST()
{
    root = nullptr;
}

BST::~BST()
{
    clearTree(root);
}

void BST::clearTree(node* node)
{
    if(node == nullptr)
        return;
    
    clearTree(node->leftChild);
    clearTree(node->rightChild);
    delete node;
}

void BST::insertNode(node*& root, int data)
{
    if(root == nullptr)
    {
        root = new node(data);
        return;
    }

    if(data < root->data)
        insertNode(root->leftChild, data);
    else if (data > root->data)
        insertNode(root->rightChild, data);
    else
        cout << "Duplicate " << data << " ignored." << endl;
}

node* BST::searchNode(node*& root, int data)
{
    if (root == nullptr || root->data == data)
        return root;
    if (data < root->data)
        return searchNode(root->leftChild, data);
    return searchNode(root->rightChild, data);
}

void BST::deleteNode(node*& root, int data)
{
    if (root == nullptr)
        return;

    if (data < root->data)
        deleteNode(root->leftChild, data);
    else if (data > root->data)
        deleteNode(root->rightChild, data);
    else {
        if (root->leftChild == nullptr) {
            node* temp = root->rightChild;
            delete root;
            root = temp;
        }
        else if (root->rightChild == nullptr) {
            node* temp = root->leftChild;
            delete root;
            root = temp;
        }
        else {
            node* temp = root->rightChild;
            while (temp->leftChild != nullptr)
                temp = temp->leftChild;
            root->data = temp->data;
            deleteNode(root->rightChild, temp->data);
        }
    }
}

void BST::preorder(node* root)
{
    if (root == nullptr)
        return;
    cout << root->data << " ";
    preorder(root->leftChild);
    preorder(root->rightChild);
}

void BST::inorder(node* root)
{
    if (root == nullptr)
        return;
    inorder(root->leftChild);
    cout << root->data << " ";
    inorder(root->rightChild);
}

void BST::postorder(node* root)
{
    if (root == nullptr)
        return;
    postorder(root->leftChild);
    postorder(root->rightChild);
    cout << root->data << " ";
}


void BST::printTree(node* root, int space)
{
    const int COUNT = 10;
    if (root == nullptr)
        return;
    space += COUNT;
    printTree(root->rightChild, space);
    for (int i = COUNT; i < space; i++)
        cout << " ";
    cout << root->data << endl;
    printTree(root->leftChild, space);
}

// Task 1: empty subtrees have height -1 and leaves have height 0.
int BST::height(node* current)
{
    if (current == nullptr)
        return -1;
    return 1 + max(height(current->leftChild), height(current->rightChild));
}

// Task 2: calculate the total from the actual nodes on every call.
int BST::countNodes(node* current)
{
    if (current == nullptr)
        return 0;
    return 1 + countNodes(current->leftChild) + countNodes(current->rightChild);
}

int BST::countNodes()
{
    return countNodes(root);
}

// Task 3: check each node, without storing heights or balance factors.
string BST::balanceHelper(node* current)
{
    if (current == nullptr)
        return "Yes";
    int difference = height(current->leftChild) - height(current->rightChild);
    if (difference > 1)
        return "Left-heavy";
    if (difference < -1)
        return "Right-heavy";

    string leftResult = balanceHelper(current->leftChild);
    if (leftResult != "Yes")
        return leftResult;
    return balanceHelper(current->rightChild);
}

string BST::isBalanced()
{
    return balanceHelper(root);
}

// Task 5: use the Assignment 1 custom queue to store node pointers.
void BST::BFS()
{
    if (root == nullptr)
        return;
    Queue queue;
    queue.enqueue(root);
    while (!queue.isEmpty())
    {
        node* current = queue.dequeue();
        cout << current->data << " ";
        if (current->leftChild != nullptr)
            queue.enqueue(current->leftChild);
        if (current->rightChild != nullptr)
            queue.enqueue(current->rightChild);
    }
}
