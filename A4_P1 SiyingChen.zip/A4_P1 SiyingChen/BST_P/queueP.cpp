#include "queueP.h"

queueNode::queueNode(node* value)
{
    data = value;
    next = nullptr;
}

Queue::Queue()
{
    front = nullptr;
    rear = nullptr;
}

Queue::~Queue()
{
    while (!isEmpty())
        dequeue();
}

void Queue::enqueue(node* value)
{
    queueNode* newNode = new queueNode(value);
    if (isEmpty())
    {
        front = newNode;
        rear = newNode;
    }
    else
    {
        rear->next = newNode;
        rear = newNode;
    }
}

node* Queue::dequeue()
{
    if (isEmpty())
        throw std::runtime_error("Queue is empty");
    queueNode* temp = front;
    node* value = front->data;
    front = front->next;
    if (front == nullptr)
        rear = nullptr;
    // Remove the queue node. The tree still owns the BST node.
    delete temp;
    return value;
}

bool Queue::isEmpty()
{
    return front == nullptr;
}
