#ifndef QUEUEA_H
#define QUEUEA_H

#include <stdexcept>

// Linked-list queue from Assignment 1, changed to store array indices.
struct queueNode
{
    int data;
    queueNode* next;
    queueNode(int value);
};

class Queue
{
    private:
        queueNode* front;
        queueNode* rear;
    public:
        Queue();
        ~Queue();
        void enqueue(int value);
        int dequeue();
        bool isEmpty();
};

#endif
