#include "bstA.h"
#include "queueA.h"

BST::BST(int size)
{
    if (size <= 0)
        throw invalid_argument("BST capacity must be positive");
    capacity = size;
    tree = new int[capacity];
    for(int i = 0; i < size; i++)
        tree[i] = INT_MIN;
}

BST::~BST()
{
    delete[] tree;
}

int BST::leftChild(int index)
{
    return 2 * index + 1;
}

int BST::rightChild(int index)
{
    return 2 * index + 2;
}

int BST::parent(int index)
{
    return (index - 1) / 2;
}

// Ignore duplicates: this BST stores each value only once.
void BST::insertI(int data)
{
    if (data == INT_MIN)
    {
        cout << "INT_MIN is reserved for empty array positions." << endl;
        return;
    }

    int index = 0;
    while (index < capacity)
    {
        if (tree[index] == INT_MIN)
        {
            tree[index] = data;
            return;
        }
        if (data == tree[index])
        {
            cout << "Duplicate " << data << " ignored." << endl;
            return;
        }
        index = data < tree[index] ? leftChild(index) : rightChild(index);
    }
    cout << "No array position available for " << data << "." << endl;
}

void BST::insertR(int data)
{
    if (data == INT_MIN)
    {
        cout << "INT_MIN is reserved for empty array positions." << endl;
        return;
    }
    insertRhelper(0, data);
}

void BST::insertRhelper(int index, int data)
{
    if (index >= capacity)
    {
        cout << "No array position available for " << data << "." << endl;
        return;
    }
    if (tree[index] == INT_MIN)
    {
        tree[index] = data;
        return;
    }
    if (data == tree[index])
    {
        cout << "Duplicate " << data << " ignored." << endl;
        return;
    }

    if (data < tree[index])
        insertRhelper(leftChild(index), data);
    else
        insertRhelper(rightChild(index), data);
}

bool BST::searchI(int data)
{
    int index = 0;

    while(index < capacity)
    {
        if(tree[index] == INT_MIN)
            return false;
        if(tree[index] == data)
            return true;
        if(data < tree[index])
            index = leftChild(index); 
        else
            index = rightChild(index);
    }

    return false;
}

bool BST::searchR(int data)
{
    return searchRhelper(0, data);
}

bool BST::searchRhelper(int index, int data)
{
    // Base case
    if(index >= capacity || tree[index] == INT_MIN)
        return false;
    if(tree[index] == data)
        return true;

    // Recursive case
    if(data < tree[index])
        return searchRhelper(leftChild(index), data);
    else
        return searchRhelper(rightChild(index), data);
}

void BST::preorder(int index) // C-L-R
{
    // base case
    if (index >= capacity || tree[index] == INT_MIN)
        return;

    // recursive case
    cout << tree[index] << " ";
    preorder(leftChild(index));
    preorder(rightChild(index));
}

void BST::inorder(int index) // L-C-R
{
    // base case
    if (index >= capacity || tree[index] == INT_MIN)
        return;

    // recursive case
    inorder(leftChild(index));
    cout << tree[index] << " ";
    inorder(rightChild(index));
}

void BST::postorder(int index) // L-R-C
{
    // base case
    if (index >= capacity || tree[index] == INT_MIN)
        return;

    // recursive case
    postorder(leftChild(index));
    postorder(rightChild(index));
    cout << tree[index] << " ";
}

void BST::printTree(int index, int depth)
{
    if(index >= capacity || tree[index] == INT_MIN)
        return;
    
    printTree(rightChild(index), depth + 1);

    for(int i = 0; i < depth; i++)
        cout << "   "; // for indentation
    cout << tree[index] << endl;

    printTree(leftChild(index), depth + 1);
    
}

// Task 1: count edges along the longest path to a leaf.
int BST::height(int index)
{
    if (index < 0 || index >= capacity || tree[index] == INT_MIN)
        return -1;
    return 1 + max(height(leftChild(index)), height(rightChild(index)));
}

// Find the array index when the command file supplies a node's value.
int BST::nodeIndex(int data)
{
    int index = 0;
    while (index < capacity && tree[index] != INT_MIN)
    {
        if (tree[index] == data)
            return index;
        index = data < tree[index] ? leftChild(index) : rightChild(index);
    }
    return -1;
}

// Task 2: compute the count recursively; no saved node count is used.
int BST::countNodes(int index)
{
    if (index < 0 || index >= capacity || tree[index] == INT_MIN)
        return 0;
    return 1 + countNodes(leftChild(index)) + countNodes(rightChild(index));
}

// Task 3: check every node, recomputing subtree heights as needed.
string BST::balanceHelper(int index)
{
    if (index >= capacity || tree[index] == INT_MIN)
        return "Yes";

    int difference = height(leftChild(index)) - height(rightChild(index));
    if (difference > 1)
        return "Left-heavy";
    if (difference < -1)
        return "Right-heavy";

    string leftResult = balanceHelper(leftChild(index));
    if (leftResult != "Yes")
        return leftResult;
    return balanceHelper(rightChild(index));
}

string BST::isBalanced()
{
    return balanceHelper(0);
}

void BST::clearSubtree(int index)
{
    if (index >= capacity || tree[index] == INT_MIN)
        return;
    clearSubtree(leftChild(index));
    clearSubtree(rightChild(index));
    tree[index] = INT_MIN;
}

void BST::copySubtree(int source, int destination, const int* original)
{
    if (source >= capacity || destination >= capacity || original[source] == INT_MIN)
        return;
    tree[destination] = original[source];
    copySubtree(leftChild(source), leftChild(destination), original);
    copySubtree(rightChild(source), rightChild(destination), original);
}

// Moving a subtree changes all its array indices. A temporary copy prevents
// destination writes from overwriting source nodes that have not moved yet.
void BST::promoteChild(int index, int child)
{
    int* original = new int[capacity];
    for (int i = 0; i < capacity; ++i)
        original[i] = tree[i];
    clearSubtree(index);
    copySubtree(child, index, original);
    delete[] original;
}

// Task 4: handle a leaf, one child, or two children.
void BST::deleteHelper(int index, int data)
{
    if (index >= capacity || tree[index] == INT_MIN)
        return;
    if (data < tree[index])
        deleteHelper(leftChild(index), data);
    else if (data > tree[index])
        deleteHelper(rightChild(index), data);
    else
    {
        int left = leftChild(index);
        int right = rightChild(index);
        bool hasLeft = left < capacity && tree[left] != INT_MIN;
        bool hasRight = right < capacity && tree[right] != INT_MIN;

        if (!hasLeft && !hasRight)
            tree[index] = INT_MIN;
        else if (!hasLeft)
            promoteChild(index, right);
        else if (!hasRight)
            promoteChild(index, left);
        else
        {
            // Replace the value with its inorder successor, then delete it.
            int successor = right;
            while (leftChild(successor) < capacity && tree[leftChild(successor)] != INT_MIN)
                successor = leftChild(successor);
            tree[index] = tree[successor];
            deleteHelper(right, tree[successor]);
        }
    }
}

void BST::deleteNode(int data)
{
    deleteHelper(0, data);
}

// Task 5: queue array indices, visiting the left child before the right.
void BST::BFS()
{
    if (tree[0] == INT_MIN)
        return;
    Queue queue;
    queue.enqueue(0);
    while (!queue.isEmpty())
    {
        int index = queue.dequeue();
        cout << tree[index] << " ";
        int left = leftChild(index);
        int right = rightChild(index);
        if (left < capacity && tree[left] != INT_MIN)
            queue.enqueue(left);
        if (right < capacity && tree[right] != INT_MIN)
            queue.enqueue(right);
    }
}
