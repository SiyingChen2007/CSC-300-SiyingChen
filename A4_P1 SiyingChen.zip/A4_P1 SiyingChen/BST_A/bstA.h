#ifndef BSTA_H
#define BSTA_H

#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <climits>
#include <algorithm>
#include <cstdlib>
#include <stdexcept>

using namespace std;

class BST
{
    private:
        int* tree;
        int capacity;

        int leftChild(int index);
        int rightChild(int index);
        int parent(int index);
        string balanceHelper(int index);
        void deleteHelper(int index, int data);
        void clearSubtree(int index);
        void copySubtree(int source, int destination, const int* original);
        void promoteChild(int index, int child);

    public:
        BST(int size);
        ~BST();

        void insertI(int data);
        void insertR(int data);
        void insertRhelper(int index, int data);

        bool searchI(int data);
        bool searchR(int data);
        bool searchRhelper(int index, int data);

        void preorder(int index = 0);
        void inorder(int index = 0);
        void postorder(int index = 0);

        void printTree(int index = 0, int depth = 0);

        // Empty subtree height is -1, so a leaf has height 0.
        int height(int index = 0);
        int nodeIndex(int data);
        int countNodes(int index = 0);
        string isBalanced();
        void deleteNode(int data);
        void BFS();
};

#endif