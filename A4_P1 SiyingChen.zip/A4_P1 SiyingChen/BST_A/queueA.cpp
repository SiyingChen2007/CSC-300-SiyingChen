#include "queueA.h"

queueNode::queueNode(int value)
{
    data = value;
    next = nullptr;
}

Queue::Queue()
{
    front = nullptr;
    rear = nullptr;
}

Queue::~Queue()
{
    while (!isEmpty())
        dequeue();
}

void Queue::enqueue(int value)
{
    queueNode* newNode = new queueNode(value);
    if (isEmpty())
    {
        front = newNode;
        rear = newNode;
    }
    else
    {
        rear->next = newNode;
        rear = newNode;
    }
}

int Queue::dequeue()
{
    if (isEmpty())
        throw std::runtime_error("Queue is empty");
    queueNode* temp = front;
    int value = front->data;
    front = front->next;
    if (front == nullptr)
        rear = nullptr;
    delete temp;
    return value;
}

bool Queue::isEmpty()
{
    return front == nullptr;
}
