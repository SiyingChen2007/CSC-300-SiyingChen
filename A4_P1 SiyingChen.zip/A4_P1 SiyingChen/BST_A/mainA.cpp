#include "bstA.h"

int main(int argc, char* argv[])
{
    if(argc != 2)
    {
        cerr <<"Usage: ./a <filename>" << endl;
        return 1;
    }

    int size = 1024;
    string filename = argv[1];

    BST bst(size);

    ifstream infile(filename);

    if(!infile)
    {
        cerr << "Error opening file" << endl;
        return 1;
    }

    string line;
    while(getline(infile, line))
    {
        istringstream iss(line);
        int command, data;
        if (!(iss >> command))
            continue;
        if ((command >= 1 && command <= 4) || command == 12)
        {
            if (!(iss >> data))
            {
                cerr << "Missing value in command: " << line << endl;
                continue;
            }
        }
        
        switch(command) {
            case 0:
                cout << "Exiting ..." << endl;
                return 0;
            case 1:
                bst.insertI(data);
                cout << "Insert I: " << data << endl;
                break;
            case 2:
                bst.insertR(data);
                cout << "Insert R: " << data << endl;
                break;
            case 3:
                if(bst.searchI(data))
                    cout << data << " found I" << endl;
                else
                    cout << data << " not found I" << endl;
                break;
            case 4:
                if(bst.searchR(data))
                    cout << data << " found R" << endl;
                else
                    cout << data << " not found R" << endl;
                break;
            case 5:
                cout << "Preorder traversal: ";
                bst.preorder();
                cout << endl;
                break;
            case 6:
                cout << "Inorder traversal: ";
                bst.inorder();
                cout << endl;
                break;
            case 7:
                cout << "Postorder traversal: ";
                bst.postorder();
                cout << endl;
                break;
            case 8:
                cout << "Binary Search Tree" << endl;
                bst.printTree(0, 0);
                cout << endl;
                break;
            case 9:
                if (iss >> data)
                {
                    int index = bst.nodeIndex(data);
                    if (index == -1)
                        cout << "Node " << data << " not found." << endl;
                    else
                        cout << "Height of " << data << ": " << bst.height(index) << endl;
                }
                else
                    cout << "Tree height: " << bst.height() << endl;
                break;
            case 10:
                cout << "Node count: " << bst.countNodes() << endl;
                break;
            case 11:
                cout << "Balanced: " << bst.isBalanced() << endl;
                break;
            case 12:
                if (bst.searchI(data))
                {
                    bst.deleteNode(data);
                    cout << "Deleted: " << data << endl;
                }
                else
                    cout << "Node " << data << " not found; nothing deleted." << endl;
                break;
            case 13:
                cout << "BFS traversal: ";
                bst.BFS();
                cout << endl;
                break;
            default:
                cout << "Invalid command" << endl;
        }
    }

    return 0;
}