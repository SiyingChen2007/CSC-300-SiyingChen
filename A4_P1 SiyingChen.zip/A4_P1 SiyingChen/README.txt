Assignment 4 Part 1
Siying Chen

This assignment uses the BST_A and BST_P starter code from class.
BST_A stores the tree in an array. BST_P uses nodes and pointers.

Functions added:
- height(): finds the height of a given node. A leaf has height 0.
- countNodes(): returns the total number of nodes.
- isBalanced(): returns Yes, Left-heavy, or Right-heavy.
- deleteNode(): added to BST_A. BST_P already had this function.
- BFS(): visits the tree level by level using a linked-list queue.

height(), countNodes(), and the balance check use recursion. They calculate
the results from the tree each time instead of using saved heights or counts.
The insert functions also check for duplicates and ignore repeated values.
The queues use the enqueue/dequeue logic from Assignment 1, with the data
changed to array indices in BST_A and node pointers in BST_P.

Compile and run from the A4_P1 folder:

Array version:
g++ -std=c++17 BST_A/mainA.cpp BST_A/bstA.cpp BST_A/queueA.cpp -o bst_a
./bst_a BST_A/demo.txt

Pointer version:
g++ -std=c++17 BST_P/mainP.cpp BST_P/bstP.cpp BST_P/queueP.cpp -o bst_p
./bst_p BST_P/demo.txt

The programs read commands from a text file, as in the starter code.
inst.txt is the original input. demo.txt checks the new functions, duplicates,
and deletion of a leaf, a node with one child, and a node with two children.
left_heavy.txt and right_heavy.txt check the two imbalance results.
empty.txt, promotion.txt, and internal_imbalance.txt contain extra test cases.

New commands in BST_A:
9       Tree height (or 9 value for the height of that node)
10      Node count
11      Balance check
12 value Delete a node
13      BFS

New commands in BST_P:
8       Tree height (or 8 value for the height of that node)
9       Node count
10      Balance check
11      BFS

An empty tree has height -1 and 0 nodes. A tree is balanced when every node's
left and right subtree heights differ by no more than 1. If several nodes
are unbalanced, the result comes from the first one in root-left-right order.
BST_A uses INT_MIN for empty positions and has an array capacity of 1024.

The results folder contains program output and images made from that output.
Add the Terminal screenshots from your own run before submitting.
