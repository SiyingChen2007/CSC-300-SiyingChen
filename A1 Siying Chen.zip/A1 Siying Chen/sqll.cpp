#include "sqll.h"

//======================= STACK ===========================

Stack::Stack()
{
    top = nullptr; 
}

Stack::~Stack() 
{
    while (!isEmpty()) 
    {
        pop();
    }
}

void Stack::push(string& value) 
{
    node* newNode = new node(value);
    newNode->next = top;
    top = newNode;
}

string Stack::pop() 
{
    if (isEmpty())
        throw runtime_error("Stack is empty");

    node* temp = top;
    string value = top->data;
    top = top->next;
    delete temp;

    return value;
}

string Stack::peek() 
{
    if (isEmpty()) 
    {
        throw runtime_error("Stack is empty");
    }

    return top->data;  
}

bool Stack::isEmpty() 
{
    return top == nullptr;
}

void Stack::display()
{
    node* current = top;
    cout << "Stack: ";
    while (current != nullptr) 
    {
        cout << current->data << " ";
        current = current->next;
    }
    cout << endl;
}

//======================= QUEUE ===========================

Queue::Queue()
{
    front = nullptr;
    rear = nullptr; 
}

Queue::~Queue() 
{
    while (!isEmpty()) 
    {
        dequeue();
    }
}

void Queue::enqueue(string& value) 
{
    node* newNode = new node(value);

    if (isEmpty()) {
        front = newNode;
        rear = newNode;
    }
    else {
        rear->next = newNode;
        rear = newNode;
    }
}

string Queue::dequeue() 
{
    if (isEmpty())
        throw runtime_error("Queue is empty");

    node* temp = front;
    string value = front->data;
    front = front->next;

    if (front == nullptr)
        rear = nullptr;

    delete temp;
    return value;
}

bool Queue::isEmpty() 
{
    return front == nullptr;
}

void Queue::display()
{
    node* current = front;
    cout << "Queue: ";
    
    while (current != nullptr) 
    {
        cout << current->data << " ";
        current = current->next;
    }
    cout << endl;
}
//======================= DIJKSTRA'S TWO STACK ===========================
double evaluateExpression(string& expr) 
{
    // complete this using stacks
    Stack values;
    Stack operators;

    string token;
    stringstream ss(expr);

    while (ss >> token)
    {
        if (token == "(")
        {
            continue;
        }
        else if (token == "+" || token == "-" || token == "*" ||
                 token == "/" || token == "^")
        {
            operators.push(token);
        }
        else if (token == ")")
        {
            string op = operators.pop();

            double right = stod(values.pop());
            double left = stod(values.pop());

            double result;

            if (op == "+")
                result = left + right;
            else if (op == "-")
                result = left - right;
            else if (op == "*")
                result = left * right;
            else if (op == "/")
                result = left / right;
            else
                result = pow(left, right);

            string resultString = to_string(result);
            values.push(resultString);
        }
        else
        {
            values.push(token);
        }
    }

    return stod(values.pop());

}

// ============= JOSEPHUS PROBLEM ===========================
void josephus(int n, int k) 
{
    // complete this using queue
    Queue q;

for (int i = 1; i <= n; i++)
{
    string soldier = to_string(i);
    q.enqueue(soldier);
}

while (true)
{
    for (int i = 1; i < k; i++)
    {
        string soldier = q.dequeue();
        q.enqueue(soldier);
    }

    string eliminated = q.dequeue();

    if (q.isEmpty())
    {
        cout << "Survivor: " << eliminated << endl;
        break;
    }

    cout << "Eliminated: " << eliminated << endl;
}
}