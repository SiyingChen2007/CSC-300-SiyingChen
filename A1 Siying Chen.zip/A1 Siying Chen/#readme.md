#readme
Siying Chen
This assignment includes implementations of stacks and queues using linked lists.Completed tasks include Stack push() and pop(), Queue enqueue() and dequeue(), Dijkstra's two-stack algorithm for fully parenthesized expressions, and the Josephus problem using a queue.
To compile:
g++ main.cpp sqll.cpp -o a1
To run:
./a1